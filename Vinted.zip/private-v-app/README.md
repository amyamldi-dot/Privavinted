# Private V - Générateur Vinted Premium

Application web premium pour générer des annonces Vinted optimisées avec 6 templates professionnels.

## 🚀 Déploiement sur GitHub Pages (GRATUIT)

### Étape 1 : Créer un compte GitHub
1. Va sur [github.com](https://github.com)
2. Clique sur "Sign up" et crée ton compte gratuitement

### Étape 2 : Créer un nouveau repository
1. Une fois connecté, clique sur le `+` en haut à droite
2. Choisis "New repository"
3. Nom du repository : `private-v` (ou ce que tu veux)
4. Mets-le en **Public**
5. Clique sur "Create repository"

### Étape 3 : Upload les fichiers
1. Sur la page de ton repository, clique sur "uploading an existing file"
2. Glisse-déposse ces 3 fichiers :
   - `index.html`
   - `manifest.json`
   - `README.md`
3. Scroll en bas et clique sur "Commit changes"

### Étape 4 : Activer GitHub Pages
1. Va dans l'onglet **Settings** de ton repository
2. Dans le menu de gauche, clique sur **Pages**
3. Sous "Source", choisis **main** branch
4. Clique sur **Save**
5. Attends 1-2 minutes

### Étape 5 : Accéder à ton app
Ton app sera disponible à l'URL :
```
https://TON-NOM-UTILISATEUR.github.io/private-v/
```

## 📱 Installer sur iPhone

### Méthode 1 : Ajouter à l'écran d'accueil
1. Ouvre l'URL dans **Safari** (pas Chrome)
2. Appuie sur le bouton **Partager** (carré avec flèche)
3. Scroll et choisis **"Sur l'écran d'accueil"**
4. Nomme-la "Private V"
5. Clique sur **Ajouter**

✅ **Maintenant tu as une vraie app sur ton iPhone !**

### Méthode 2 : Raccourci direct (sans GitHub)
Si tu ne veux pas utiliser GitHub :
1. Upload `index.html` sur un service comme [Netlify Drop](https://app.netlify.com/drop)
2. Glisse le fichier
3. Tu obtiens un lien instantané
4. Ajoute ce lien à ton écran d'accueil

## ✨ Fonctionnalités

- ✅ **6 templates premium** : Minimal, Premium, Luxury, Emoji, Modern, Compact
- ✅ **Sauvegarde automatique** : Tes données sont conservées
- ✅ **Fonctionne offline** : Une fois chargée, tu peux l'utiliser sans internet
- ✅ **Optimisé iPhone** : Interface adaptée, gestes tactiles
- ✅ **Copie en 1 clic** : Bouton pour copier l'annonce
- ✅ **Design liquid glass** : Effet premium animé

## 🎨 Templates disponibles

1. **Minimal** - Épuré, symboles simples
2. **Premium Box** - Cadres élégants
3. **Luxury** - Séparateurs sophistiqués
4. **Emoji Style** - Emojis stratégiques
5. **Modern Clean** - Minimaliste moderne
6. **Compact Pro** - Ultra-compact

## 💡 Utilisation

1. Remplis les champs (description, marque, taille, etc.)
2. Choisis un template
3. Clique sur "Générer"
4. Copie et colle sur Vinted

---

**Made with 🖤 by Private V**
